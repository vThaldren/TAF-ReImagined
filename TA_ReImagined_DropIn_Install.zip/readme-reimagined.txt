TA, Re-Imagined!
